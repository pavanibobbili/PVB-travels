<?php
include 'db_connection.php'; // Include the database connection script

// Perform SQL query to retrieve data
$sql = "SELECT * FROM login";
$result = $conn->query($sql);

// Check if there's data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Name: " . $row["name"] . "<br>";
    }
} else {
    echo "No data found.";
}

$conn->close();
?>

