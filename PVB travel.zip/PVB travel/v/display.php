<?php

$host = "localhost";
$username = "root";
$password = "pavani123";
$db_name = "pvb";
$tbl_name = "login";

// Create a new MySQLi connection
$conn = new mysqli($host, $username, $password, $db_name);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you have stored the authenticated user's details in session or some other way
// Retrieve the authenticated user's details
$authenticatedUser = $_SESSION['name']; // Replace with your actual session variable authenticatedUser

// Fetch the customer details based on the authenticated user's information
$sql = "SELECT * FROM $tbl_name WHERE name=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $authenticatedUser);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Display customer details
    $row = $result->fetch_assoc();
    
    echo "Customer Name: " . $row["name"] . "<br>";
    echo "Email: " . $row["email"] . "<br>";
    echo "Phone: " . $row["phone"] . "<br>";
    // ... display other details ...
} else {
    echo "No customer details found.";
}

// Close the prepared statement and database connection
$stmt->close();
$conn->close();

?>

