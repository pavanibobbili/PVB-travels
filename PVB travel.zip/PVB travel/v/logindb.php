<?php

$host="localhost";

$username="root";

$password="pavani123";

$db_name="pvb";

$tbl_name="login";

$conn = mysql_connect("$host", "$username", "$password")or die("cannot connect");

mysql_select_db("$db_name")or die("cannot select DB");

    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $location = $_POST["location"];
    $guests = $_POST["guests"];
    $arrivals = $_POST["arrivals"];
    $leaving = $_POST["leaving"];


$name = stripslashes($name);
$email = stripslashes($email);
$phone = stripslashes($phone);
$address = stripslashes($address);
$location = stripslashes($location);
$guests = stripslashes($guests);
$arrivals = stripslashes($arrivals);
$leaving = stripslashes($leaving);

$name = mysql_real_escape_string($name);
$email = mysql_real_escape_string($email);
$phone= mysql_real_escape_string($phone);
$address = mysql_real_escape_string($address);
$location = mysql_real_escape_string($location);
$guests = mysql_real_escape_string($guests);
$arrivals = mysql_real_escape_string($arrivals);
$leaving = mysql_real_escape_string($leaving);


$sql="select * from $tbl_name where name='$name' AND email='$email' AND phone='$phone' AND address='$address' AND location='$location' AND guests='$guests' AND arrivals='$arrivals' AND leaving='$leaving'";

$result=mysql_query($sql,$conn);

$count=mysql_num_rows($result);

if ($count == 1)
{
echo ":) :) LOGIN SUCCESS :) :) ";
?>

<meta http-equiv = "refresh" content = "5; url="http://localhost/PVB%20travel/display.php" />

<?
}

else 
{
echo ":( :( AUTHETICATION FAILURE :( :( ";
}

?>
