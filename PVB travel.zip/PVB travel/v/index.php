<?php
$host = 'localhost'; // Change this to your MySQL server host if needed
$db = 'pvb'; // Change this to your database name
$user = 'root'; // Change this to your MySQL username
$password = 'pavani123'; // Change this to your MySQL password

// Create a connection
$conn = new mysqli($host, $user, $password, $db);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Responsive website developing by Win Coder</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"><span>PVB</span>travel</a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#service">service</a>
        <a href="#about">about</a>
        <a href="#gallery">gallery</a>
        <a href="#package">package</a>
        <a href="#review">reivew</a>
        <a href="#book">book</a>
    </nav>

    <div id="menu-bars" class="fas fa-bars"></div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="content">
        <h3>“Adventures are the best way to learn.”<span>PVBtravel..</span></h3>
        <a href="#book" class="btn">book us</a>
    </div>

    <div class="swiper-container home-slider">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="images/slide-1.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/slide-2.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/slide-3.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/slide-4.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/slide-5.jpg" alt=""></div>
            <div class="swiper-slide"><img src="images/slide-6.jpg" alt=""></div>
        </div>
    </div>

</section>

   <!-- home section ends -->

   <!-- service section starts -->

   <section class="service" id="service">

    <h1 class="heading"> our <span>services</span> </h1>

    <div class="box-container">

        <div class="box">
            <i class="fas fa-map-marker-alt"></i>
            <h3>place selection</h3>
            <p>Explore The Best Regions For Shopping, Food, Culture, Mountains, Sea, Culture And Camping. </p>
        </div>

        <div class="box">
            <i class="fa fa-solid fa-car"></i>
            <h3>transport</h3>
            <p>Find Transporting Services with us at PVB travels </p>
        </div>

        <div class="box">
            <i class="fas fa-music"></i>
            <h3>entertainment</h3>
            <p> Winter Experiences. Family Holiday Packages. Adventure Activities. Historic & Cultural Sites.</p>
        </div>

        <div class="box">
            <i class="fas fa-utensils"></i>
            <h3>food and drinks</h3>
            <p>A Food and Drinks  includes food and beverage tastings related to a place where we visit. It can be about the local culture or a specific region of the city.</p>
        </div>

        <div class="box">
            <i class="fas fa-photo-video"></i>
            <h3>photos and videos</h3>
            <p>Make this travel memorable with photos and videos.</p>
        </div>

        <div class="box">
            <i class="fas fa-birthday-cake"></i>
            <h3>custom food</h3>
            <p>We were given the task to develop a custom food tour focusing on such popular trends as veganism, trans-cultural cooking and the use of non-traditional .</p>
        </div>

    </div>

</section>


    <!-- service section ends -->

    <!-- about section starts  -->

    <section class="about" id="about">

        <h1 class="heading"><span>about</span> us</h1>
        <div class="row">

            <div class="image">
                <img src="images/about-img.jpg" alt="">
            </div>
            
            <div class="content">

                <h3>PVBtravels is the name of travel technology solution.</h3>
                <p>Dominating the landscape of South Asia, India is home to millions of attractions and billions of experiences. Blessed with varied geographical features, India has a vast diversity of hills, plateaus, beaches, backwaters, islands, forests, deserts, and more. Be a part of yoga retreats, go for pilgrimages, or take up Ayurveda therapies or spa sessions. A holiday trip across India is worth every penny.</p>
                <p>Booking a tour at PVBtravels is quick, simple, and effective. Most of our pages feature an elaborate inquiry form where you can mention your email, list some basic tour specifics or even jot down a question. That's it! Our tour expert promptly reverts to your inquiry, and within no time, your tour to India is booked.</p>
               <a href="#" class="btn">contact us</a>
            </div>

        </div>

    </section>

    <!-- about section ends  -->

    <!-- gallery section starts  -->

<section class="gallery" id="gallery">

    <h1 class="heading">our <span>gallery</span></h1>

    <div class="box-container">

        <div class="box">
            <img src="images/g-1.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-2.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-3.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-4.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-5.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-6.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-7.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-8.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="images/g-9.jpg" alt="">
            <h3 class="title">PVB gallery</h3>
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

    </div>

</section>

<!-- gallery section ends -->

<!-- package section starts -->

<section class="package" id="package">

<div class="heading" style="background: url(images/header-bg-2.png) no-repeat">
<h1 class="heading"> our<span> package</span></h1>
</div>

<h1 class="heading-title">select your destinations</h1>

<div class="box-container">

    <div class="box">
        <div class="image">
            <img src="images/img-1.jpg" alt="">
        </div>
        <div class="content">
            <h3>AGRA</h3>
            <p> taj mahal which is symbolic place for love</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-2.jpg" alt="">
        </div>
        <div class="content">
            <h3>GOA</h3>
            <p> goa is smallest state in western india</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-3.jpg" alt="">
        </div>
        <div class="content">
            <h3>SHIMLA</h3>
            <p>which is very beautiful place surrounded by hills.</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-4.jpg" alt="">
        </div>
        <div class="content">
            <h3>MANALI</h3>
            <p>unlimited adventure oppurtunites</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-5.jpg" alt="">
        </div>
        <div class="content">
            <h3>OOTY</h3>
            <p>queen of hill stations</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-6.jpg" alt="">
        </div>
        <div class="content">
            <h3>Kodikanal</h3>
            <p>competing with the fruit trees are the flowering ones</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-7.jpg" alt="">
        </div>
        <div class="content">
            <h3>Munnar</h3>
            <p>virgin forests,savannah,rolling hills,scenic valleys</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-8.jpg" alt="">
        </div>
        <div class="content">
            <h3>ALLEPPEY</h3>
            <p>.famous for its boat races,beaches,marine products and coir industry</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-9.jpg" alt="">
        </div>
        <div class="content">
            <h3>kovalam</h3>
            <p>kovalam nigth life is by no means a quiet affair</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-10.jpg" alt="">
        </div>
        <div class="content">
            <h3>Win Coder Sujon Biswas</h3>
            <p>Mayabi Waterfall Jaflong tour.I visited this place in 2020</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-11.jpg" alt="">
        </div>
        <div class="content">
            <h3>thekkady</h3>
            <p>dense evergreen ,moist deciduous forests</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>

    <div class="box">
        <div class="image">
            <img src="images/img-12.jpg" alt="">
        </div>
        <div class="content">
            <h3>kumily</h3>
            <p>one of the important tourists and commercial centres</p>
            <a href="#book" class="btn">book now</a>
        </div>
    </div>
</div>

<div class="load-more"><span class="btn">load more...</span></div>

</section>

    <!-- package section ends -->

    <!-- review section starts -->

<section class="reivew" id="review">

   <h1 class="heading">client's <span>review</span></h1>
   <div class="review-slider swiper-container">
     <div class="swiper-wrapper">

        <div class="swiper-slide box">
            <i class="fas fa-quote-right"></i>
            <div class="user">
                <img src="images/ravi.jpg" alt="">
                <div class="user-info">
                    <h3>ravi</h3>
                    <span>happy client</span>
                </div>
            </div>
            <p>We had a trip, the travel agent had everything perfectly planned for us. We just had to sit back and relax. A great thanks to S Vietnam trips and travel triangle for making it a perfect vacation.Everything was smooth . Our stays in both the places were great . Breakfast facilities were good have good options for vegetarian people also .</p>
        </div>

        <div class="swiper-slide box">
            <i class="fas fa-quote-right"></i>
            <div class="user">
                <img src="images/amit.jpeg" alt="">
                <div class="user-info">
                    <h3>Amit</h3>
                    <span>happy client</span>
                </div>
            </div>
            <p>Amit, it was a great experience while traveling to Europe as per the itinerary made by you. Everything was so perfect. It was a hassle-free trip. Very much satisfied with the services you gave to us from day one. Easy accessible, and prompt in replying to calls/messages. Excellent Experience. Once again thanks. Highly recommended and looking forward to traveling with Travel Triangle in the future as well. </p>
        </div>

        <div class="swiper-slide box">
            <i class="fas fa-quote-right"></i>
            <div class="user">
                <img src="images/preethi.jpg" alt="">
                <div class="user-info">
                    <h3>preethi</h3>
                    <span>happy client</span>
                </div>
            </div>
            <p>Hello , thank you so much for great tour . Our family loved it . Whether it's the villa or hotel both were great . Transportation facility was way beyond words the driver we got was the best . Nice , polite and so cooperative . Everything was smooth . Our stays in both the places were great . Breakfast facilities were good have good options for vegetarian people also . Thank you so much for great service . Totally worth the money</p>
        </div>
     </div>

   </div>

</section>

      <!-- review section ends -->

       <!-- booking section starts -->

       <section class="book" id="book">
        <div class="heading" style="background: url(images/header-bg-3.png) no-repeat">
            <h1 class="heading"> book<span>now</span> </h1>
            </div>

            <h1 class="heading-title">book your trip!</h1>
            <form action="db_connection.php" method="post" class="book-form">
              
                <div class="flex">
                    <div class="inputBox">
                        <span>name :</span>
                        <input type="text" placeholder="enter your name" name="name">
                    </div>
                    <div class="inputBox">
                        <span>email :</span>
                        <input type="email" placeholder="enter your email" name="email">
                    </div>
                    <div class="inputBox">
                        <span>phone :</span>
                        <input type="number" placeholder="enter your number" name="phone">
                    </div>
                    <div class="inputBox">
                        <span>address :</span>
                        <input type="text" placeholder="enter your address" name="address">
                    </div>
                    <div class="inputBox">
                        <span>where to :</span>
                        <input type="text" placeholder="place you want to visit" name="location">
                    </div>
                    <div class="inputBox">
                        <span>how many :</span>
                        <input type="number" placeholder="number of guests" name="guests">
                    </div>
                    <div class="inputBox">
                        <span>arrivals :</span>
                        <input type="date"  name="arrivals">
                    </div>
                    <div class="inputBox">
                        <span>leaving :</span>
                        <input type="date"  name="leaving">
                    </div>
                </div>

                <input type="submit" value="submit" class="btn" name="send">

            </form>

       </section>

          <!-- booking section ends -->

          <!-- footer section starts -->
   
          <section class="footer">

            <div class="box-container">
        
                <div class="box">
                    <h3>branches</h3>
                    <a href="#"> <i class="fas fa-map-marker-alt"></i> bangladesh </a>
                    <a href="#"> <i class="fas fa-map-marker-alt"></i> india </a>
                    <a href="#"> <i class="fas fa-map-marker-alt"></i>canada </a>
                    <a href="#"> <i class="fas fa-map-marker-alt"></i> uk </a>
                    <a href="#"> <i class="fas fa-map-marker-alt"></i> german </a>
                    <a href="#"> <i class="fas fa-map-marker-alt"></i> switzerland </a>
                </div>
        
                <div class="box">
                    <h3>quick links</h3>
                    <a href="#home"> <i class="fas fa-arrow-right"></i> home </a>
                    <a href="#service"> <i class="fas fa-arrow-right"></i> service </a>
                    <a href="#about"> <i class="fas fa-arrow-right"></i> about </a>
                    <a href="#gallery"> <i class="fas fa-arrow-right"></i> gallery </a>
                    <a href="#package"> <i class="fas fa-arrow-right"></i> package </a>
                    <a href="#review"> <i class="fas fa-arrow-right"></i> review </a>
                    <a href="#book"> <i class="fas fa-arrow-right"></i> book </a>
                </div>
        
                <div class="box">
                    <h3>contact info</h3>
                    <a href="#"> <i class="fas fa-phone"></i> +8801688238801 </a>
                    <a href="#"> <i class="fas fa-phone"></i> +8801782546978 </a>
                    <a href="#"> <i class="fas fa-envelope"></i> pvbtravels@gmail.com </a>
                    <a href="#"> <i class="fas fa-envelope"></i> sujoncse26@gmail.com </a>
                    <a href="#"> <i class="fas fa-map-marker-alt"></i> sylhet, bangladesh </a>
                </div>
        
                <div class="box">
                    <h3>follow us</h3>
                    <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
                    <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
                    <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
                    <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
                </div>
        
            </div>
        
            <div class="credit"> created by <span>PVB</span> | all rights reserved 2023 </div>
        
        </section>
           
          <!-- footer section ends -->

          <!-- theme toggler starts -->

          <div class="theme-toggler">

            <div class="toggle-btn">
                <i class="fas fa-cog"></i>
            </div>
        
            <h3>choose pvb color</h3>
        
            <div class="buttons">
                <div class="theme-btn" style="background: #3867d6;"></div>
                <div class="theme-btn" style="background: #f7b731;"></div>
                <div class="theme-btn" style="background: #ff0033;"></div>
                <div class="theme-btn" style="background: #20bf6b;"></div>
                <div class="theme-btn" style="background: #fa8231;"></div>
                <div class="theme-btn" style="background: #FC427B;"></div>
                <div class="theme-btn" style="background: #00a8ff;"></div>
                <div class="theme-btn" style="background: #8e44ad;"></div>
                <div class="theme-btn" style="background: #efd8f9;"></div>
                
            </div>
        
        </div>
        
   
        <!-- theme toggler ends -->
   
      <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

    <!-- custom js file link -->
   <script src="js/script.js"></script>
</body>
</html>



