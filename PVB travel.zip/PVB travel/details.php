<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserted Details</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
        }
    </style>
</head>
<body>

<?php
if (isset($_GET['success']) && $_GET['success'] == 'true') {
    echo "<h2>Details Successfully Inserted:</h2>";
    echo "<table>";
    echo "<tr><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Location</th><th>Guests</th><th>Arrivals</th><th>Leaving</th></tr>";
    echo "<tr>";
    echo "<td>" . $_GET['name'] . "</td>";
    echo "<td>" . $_GET['email'] . "</td>";
    echo "<td>" . $_GET['phone'] . "</td>";
    echo "<td>" . $_GET['address'] . "</td>";
    echo "<td>" . $_GET['location'] . "</td>";
    echo "<td>" . $_GET['guests'] . "</td>";
    echo "<td>" . $_GET['arrivals'] . "</td>";
    echo "<td>" . $_GET['leaving'] . "</td>";
    echo "</tr>";
    echo "</table>";
} else {
    echo "Details insertion was not successful.";
}
?>

</body>
</html>

