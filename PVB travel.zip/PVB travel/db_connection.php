<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $host = 'localhost';
    $db = 'pvb'; 
    $user = 'root'; 
    $password = 'pavani123'; 

  
    $conn = new mysqli($host, $user, $password, $db);

   
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $location = $_POST["location"];
    $guests = $_POST["guests"];
    $arrivals = $_POST["arrivals"];
    $leaving = $_POST["leaving"];

   
    $sql = "INSERT INTO login (name, email, phone, address, location, guests, arrivals, leaving)
            VALUES ('$name', '$email', '$phone', '$address', '$location', '$guests', '$arrivals', '$leaving')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";

	if ($conn->query($sql) === TRUE) {
    header("Location: details.php?   success=true&name=$name&email=$email&phone=$phone&address=$address&location=$location&guests=$guests&arrivals=$arrivals&leaving=$leaving");
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

